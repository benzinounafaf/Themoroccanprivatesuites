<?php

namespace MPHB\Exceptions;

class RequestException extends MPHBException {}
