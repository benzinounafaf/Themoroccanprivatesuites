<?php

namespace MPHB\Admin\Fields;

class PostIdField extends TextField {

	const TYPE = 'post-id';

}
