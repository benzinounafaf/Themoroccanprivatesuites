<?php
namespace HotellerElementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Distortion Grid
 *
 * @since 1.0.0
 */
class Hoteller_Distortion_Grid extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'hoteller-distortion-grid';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Distortion Hover Grid', 'hoteller-elementor' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-columns';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'hoteller-theme-widgets-category' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'imagesloaded', 'three', 'TweenMax', 'hover', 'hoteller-elementor' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'hoteller-elementor' ),
			]
		);
		
		$this->add_control(
			'slides',
			[
				'label' => __( 'Slides', 'hoteller-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'slide_title' => 'Superior Room',
						'slide_subtitle' => 'From $199',
						'slide_link_title' => 'Book Now',
					],
				],
				'fields' => [
					[
						'name' => 'slide_image',
						'label' => __( 'Image', 'hoteller-elementor' ),
						'type' => Controls_Manager::MEDIA,
						'label_block' => true,
					],
					[
						'name' => 'slide_image_hover',
						'label' => __( 'Image on hover', 'hoteller-elementor' ),
						'type' => Controls_Manager::MEDIA,
						'label_block' => true,
					],
					[
						'name' => 'slide_title',
						'label' => __( 'Title', 'hoteller-elementor' ),
						'type' => Controls_Manager::TEXT,
						'default' => __( 'Title' , 'hoteller-elementor' ),
					],
					[
						'name' => 'slide_subtitle',
						'label' => __( 'Sub Title', 'hoteller-elementor' ),
						'type' => Controls_Manager::TEXT,
					],
					[
						'name' => 'slide_excerpt',
						'label' => __( 'Excerpt', 'hoteller-elementor' ),
						'type' => Controls_Manager::TEXTAREA,
						'default' => __( 'Excerpt' , 'hoteller-elementor' ),
					],
					[
						'name' => 'slide_link_title',
						'label' => __( 'Link Title', 'hoteller-elementor' ),
						'type' => Controls_Manager::TEXT,
						'default' => __( 'Link Title' , 'hoteller-elementor' ),
					],
					[
						'name' => 'slide_link',
						'label' => __( 'Link URL', 'hoteller-elementor' ),
						'type' => Controls_Manager::URL,
						'default' => [
					        'url' => '',
					        'is_external' => '',
					     ],
						'show_external' => true,
					],
				],
				'title_field' => '{{{ slide_title }}}',
			]
		);
		
		$this->add_control(
		  'theme',
		  [
		     'label'       => __( 'Theme', 'hoteller-elementor' ),
		     'type' => Controls_Manager::SELECT,
		     'default' => 1,
		     'options' => [
			   1 => __( 'Theme 1', 'hoteller-elementor' ),
			   2 => __( 'Theme 2', 'hoteller-elementor' ),
			   3 => __( 'Theme 3', 'hoteller-elementor' ),
			   4 => __( 'Theme 4', 'hoteller-elementor' ),
			   5 => __( 'Theme 5', 'hoteller-elementor' ),
			   6 => __( 'Theme 6', 'hoteller-elementor' ),
			   7 => __( 'Theme 7', 'hoteller-elementor' ),
			   8 => __( 'Theme 8', 'hoteller-elementor' ),
			   9 => __( 'Theme 9', 'hoteller-elementor' ),
			   10 => __( 'Theme 10', 'hoteller-elementor' ),
			],
		  ]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_title_style',
			array(
				'label'      => esc_html__( 'Title', 'hoteller-elementor' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);
		
		$this->add_control(
		    'title_color',
		    [
		        'label' => __( 'Title Color', 'hoteller-elementor' ),
		        'type' => Controls_Manager::COLOR,
		        'default' => '#ffffff',
		        'selectors' => [
		            '{{WRAPPER}} h2.distortion_grid_item-title' => 'color: {{VALUE}}',
		        ],
		    ]
		);
		
		$this->add_control(
		    'title_font_size',
		    [
		        'label' => __( 'Title Font Size (* DEPRECIATED)', 'hoteller-elementor' ),
		        'type' => Controls_Manager::SLIDER,
		        'default' => [
		            'size' => 46,
		        ],
		        'range' => [
		            'px' => [
		                'min' => 10,
		                'max' => 300,
		                'step' => 1,
		            ],
		        ],
		        'size_units' => [ 'px' ],
		        'selectors' => [
		            '{{WRAPPER}} .distortion_grid_item-content h2.distortion_grid_item-title' => 'font-size: {{SIZE}}{{UNIT}};',
		        ],
		    ]
		);
		
		$this->add_control(
		    'title_line_height',
		    [
		        'label' => __( 'Title Line Height (* DEPRECIATED)', 'hoteller-elementor' ),
		        'type' => Controls_Manager::SLIDER,
		        'default' => [
		            'size' => 1.1,
		        ],
		        'range' => [
		            'px' => [
		                'min' => 0.1,
		                'max' => 2,
		                'step' => 0.1,
		            ],
		        ],
		        'size_units' => [ 'px' ],
		        'selectors' => [
		            '{{WRAPPER}} div.distortion_grid_item-content h2.distortion_grid_item-title' => 'line-height: {{SIZE}};',
		        ],
		    ]
		);
		
		$this->add_control(
		    'title_letter_spacing',
		    [
		        'label' => __( 'Title Letter Spacing (* DEPRECIATED)', 'hoteller-elementor' ),
		        'type' => Controls_Manager::SLIDER,
		        'default' => [
		            'size' => 0,
		        ],
		        'range' => [
		            'px' => [
		                'min' => -20,
		                'max' => 20,
		                'step' => 1,
		            ],
		        ],
		        'size_units' => [ 'px' ],
		        'selectors' => [
		            '{{WRAPPER}} .distortion_grid_item div.distortion_grid_item-content h2.distortion_grid_item-title' => 'letter-spacing: {{SIZE}}{{UNIT}};',
		        ],
		    ]
		);
		
		$this->add_control(
			'title_text_transform',
			[
				'label' => __( 'Title Text Transform (* DEPRECIATED)', 'hoteller-elementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'none',
			    'options' => [
			     	'none' => __( 'None', 'hoteller-elementor' ),
			     	'uppercase' => __( 'Uppercase', 'hoteller-elementor' ),
			     	'lowercase' => __( 'Lowercase', 'hoteller-elementor' ),
			     	'capitalize' => __( 'Capitalize', 'hoteller-elementor' ),
			    ],
			    'selectors' => [
		            '{{WRAPPER}} div.distortion_grid_item div.distortion_grid_item-content h2.distortion_grid_item-title' => 'text-transform: {{VALUE}}',
		        ],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __( 'Title Typography', 'hoteller-elementor' ),
				'selector' => '{{WRAPPER}} div.distortion_grid_item div.distortion_grid_item-content h2.distortion_grid_item-title',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_subtitle_style',
			array(
				'label'      => esc_html__( 'Sub Title', 'hoteller-elementor' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);
		
		$this->add_control(
		    'subtitle_color',
		    [
		        'label' => __( 'Sub Title Color', 'hoteller-elementor' ),
		        'type' => Controls_Manager::COLOR,
		        'default' => '#ffffff',
		        'selectors' => [
		            '{{WRAPPER}} .distortion_grid_item-meta' => 'color: {{VALUE}}',
		        ],
		    ]
		);
		
		$this->add_control(
		    'subtitle_font_size',
		    [
		        'label' => __( 'Sub Title Font Size (* DEPRECIATED)', 'hoteller-elementor' ),
		        'type' => Controls_Manager::SLIDER,
		        'default' => [
		            'size' => 14,
		        ],
		        'range' => [
		            'px' => [
		                'min' => 8,
		                'max' => 50,
		                'step' => 1,
		            ],
		        ],
		        'size_units' => [ 'px' ],
		        'selectors' => [
		            '{{WRAPPER}} span.distortion_grid_item-meta' => 'font-size: {{SIZE}}{{UNIT}};',
		        ],
		    ]
		);
		
		$this->add_control(
		    'subtitle_letter_spacing',
		    [
		        'label' => __( 'Sub Title Letter Spacing (* DEPRECIATED)', 'hoteller-elementor' ),
		        'type' => Controls_Manager::SLIDER,
		        'default' => [
		            'size' => 3,
		        ],
		        'range' => [
		            'px' => [
		                'min' => -10,
		                'max' => 10,
		                'step' => 1,
		            ],
		        ],
		        'size_units' => [ 'px' ],
		        'selectors' => [
		            '{{WRAPPER}} .distortion_grid_item-content span.distortion_grid_item-meta' => 'letter-spacing: {{SIZE}}{{UNIT}};',
		        ],
		    ]
		);
		
		$this->add_control(
			'subtitle_text_transform',
			[
				'label' => __( 'Sub Title Text Transform (* DEPRECIATED)', 'hoteller-elementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'uppercase',
			    'options' => [
			     	'none' => __( 'None', 'hoteller-elementor' ),
			     	'uppercase' => __( 'Uppercase', 'hoteller-elementor' ),
			     	'lowercase' => __( 'Lowercase', 'hoteller-elementor' ),
			     	'capitalize' => __( 'Capitalize', 'hoteller-elementor' ),
			    ],
			    'selectors' => [
		            '{{WRAPPER}} div.distortion_grid_item-content span.distortion_grid_item-meta' => 'text-transform: {{VALUE}}',
		        ],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typography',
				'label' => __( 'Sub Title Typography', 'hoteller-elementor' ),
				'selector' => '{{WRAPPER}} div.distortion_grid_item-content span.distortion_grid_item-meta',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_excerpt_style',
			array(
				'label'      => esc_html__( 'Excerpt', 'hoteller-elementor' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);
		
		$this->add_control(
		    'excerpt_color',
		    [
		        'label' => __( 'Excerpt Color', 'hoteller-elementor' ),
		        'type' => Controls_Manager::COLOR,
		        'default' => '#ffffff',
		        'selectors' => [
		            '{{WRAPPER}} .distortion_grid_item-subtitle span' => 'color: {{VALUE}}',
		        ],
		    ]
		);
		
		$this->add_control(
		    'excerpt_font_size',
		    [
		        'label' => __( 'Excerpt Font Size (* DEPRECIATED)', 'hoteller-elementor' ),
		        'type' => Controls_Manager::SLIDER,
		        'default' => [
		            'size' => 20,
		        ],
		        'range' => [
		            'px' => [
		                'min' => 8,
		                'max' => 50,
		                'step' => 1,
		            ],
		        ],
		        'size_units' => [ 'px' ],
		        'selectors' => [
		            '{{WRAPPER}} div.distortion_grid_item-subtitle span' => 'font-size: {{SIZE}}{{UNIT}};',
		        ],
		    ]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_typography',
				'label' => __( 'Excerpt Typography', 'hoteller-elementor' ),
				'selector' => '{{WRAPPER}} div.distortion_grid_item-subtitle span',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_link_style',
			array(
				'label'      => esc_html__( 'Link', 'hoteller-elementor' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			)
		);
		
		$this->add_control(
		    'link_color',
		    [
		        'label' => __( 'Link Color', 'hoteller-elementor' ),
		        'type' => Controls_Manager::COLOR,
		        'default' => '#ffffff',
		        'selectors' => [
		            '{{WRAPPER}} .distortion_grid_item-link' => 'color: {{VALUE}}',
		        ],
		    ]
		);
		
		$this->add_control(
		    'link_hover_color',
		    [
		        'label' => __( 'Link Hover Color', 'hoteller-elementor' ),
		        'type' => Controls_Manager::COLOR,
		        'default' => '#ffffff',
		        'selectors' => [
		            '{{WRAPPER}} .distortion_grid_item-link:focus, {{WRAPPER}} .distortion_grid_item-link:hover' => 'color: {{VALUE}}',
		        ],
		    ]
		);
		
		$this->add_control(
		    'link_font_size',
		    [
		        'label' => __( 'Link Font Size (* DEPRECIATED)', 'hoteller-elementor' ),
		        'type' => Controls_Manager::SLIDER,
		        'default' => [
		            'size' => 18,
		        ],
		        'range' => [
		            'px' => [
		                'min' => 8,
		                'max' => 50,
		                'step' => 1,
		            ],
		        ],
		        'size_units' => [ 'px' ],
		        'selectors' => [
		            '{{WRAPPER}} a.distortion_grid_item-link' => 'font-size: {{SIZE}}{{UNIT}};',
		        ],
		    ]
		);
		
		$this->add_control(
		    'link_letter_spacing',
		    [
		        'label' => __( 'Link Letter Spacing (* DEPRECIATED)', 'hoteller-elementor' ),
		        'type' => Controls_Manager::SLIDER,
		        'default' => [
		            'size' => 3,
		        ],
		        'range' => [
		            'px' => [
		                'min' => -10,
		                'max' => 10,
		                'step' => 1,
		            ],
		        ],
		        'size_units' => [ 'px' ],
		        'selectors' => [
		            '{{WRAPPER}} .distortion_grid_item-subtitle .distortion_grid_item-link' => 'letter-spacing: {{SIZE}}{{UNIT}};',
		        ],
		    ]
		);
		
		$this->add_control(
			'link_text_transform',
			[
				'label' => __( 'Link Text Transform (* DEPRECIATED)', 'hoteller-elementor' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'uppercase',
			    'options' => [
			     	'none' => __( 'None', 'hoteller-elementor' ),
			     	'uppercase' => __( 'Uppercase', 'hoteller-elementor' ),
			     	'lowercase' => __( 'Lowercase', 'hoteller-elementor' ),
			     	'capitalize' => __( 'Capitalize', 'hoteller-elementor' ),
			    ],
			    'selectors' => [
		            '{{WRAPPER}} .distortion_grid_item-subtitle a.distortion_grid_item-link' => 'text-transform: {{VALUE}}',
		        ],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'link_typography',
				'label' => __( 'Link Typography', 'hoteller-elementor' ),
				'selector' => '{{WRAPPER}} .distortion_grid_item-subtitle a.distortion_grid_item-link',
			]
		);
		
		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		include(HOTELLER_ELEMENTOR_PATH.'templates/distortion-grid/index.php');
	}

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _content_template() {
		return '';
	}
}
